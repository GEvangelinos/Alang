#ifndef DEFAULT_CONSTANTS_HPP
#define DEFAULT_CONSTANTS_HPP

namespace Arguinator
{
    namespace FlagConsts
    {
        static constexpr auto default_arity = 1;
        static const char default_help_text[] = "";
        static constexpr auto default_required = false;

    }

    namespace ParserConsts
    {
        static constexpr auto default_case_sensitive = true;
        static const char default_flag_prefix[] = "--";
        static const char default_help_flag[] = "help";
        static const char default_help_text[] = "Show this help message and exit";

        static constexpr auto default_flag_field_size = 20;
    }

}

#endif /* DEFAULT_CONSTANTS_HPP */